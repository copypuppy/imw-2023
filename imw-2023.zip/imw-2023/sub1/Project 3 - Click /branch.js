export class Branch {
  constructor(startX, startY, endX, endY, lineWidth, isFirstBranch) {
    this.startX = startX;
    this.startY = startY;
    this.endX = endX;
    this.endY = endY;
    this.lineWidth = lineWidth;
    this.isFirstBranch = isFirstBranch;

    // 가지를 100등분으로 나누기 위한 변수 frame 선언 Variable frame declaration to divide a branch into 100 equal parts
    this.frame = 10;
    // current frame
    this.cntFrame = 0;

    // 가지의 길이를 frame으로 나누어 구간별 길이를 구함 Divide the length of the branch by frame to find the length of each section
    this.gapX = (this.endX - this.startX) / this.frame;
    this.gapY = (this.endY - this.startY) / this.frame;

    // 구간별 가지가 그려질 때 끝 좌표 End coordinates when a branch by section is drawn
    this.currentX = this.startX;
    this.currentY = this.startY;
  }

  draw(ctx) {
    // 현재 frame인 cntFrame이 설정한 frame과 같다면 draw를 하지 않는다.
    if (this.cntFrame === this.frame) return true;
  
    ctx.beginPath();
  
    // 구간별 길이를 더해주어 다음 구간의 끝 좌표를 구함 Add the length of each section to obtain the end coordinates of the next section
    this.currentX += this.gapX;
    this.currentY += this.gapY;
  
    ctx.moveTo(this.startX, this.startY);
    ctx.lineTo(this.currentX, this.currentY); // 끝 좌표를 currentX,Y로 End coordinates to currentX,Y
  
    ctx.lineWidth = this.lineWidth;
  
    if (this.isFirstBranch && this.cntFrame <= 15) {
      ctx.strokeStyle = '#8B4513'; // Brown color for the first frame of the first branch
    } else {
      ctx.strokeStyle = '#008000'; // Green color for all other branches
    }
  
    ctx.stroke();
    ctx.closePath();
  
    this.cntFrame++; // 현재 프레임수 증가 Increasing the current number of frames
  
    return false;
  }

}
