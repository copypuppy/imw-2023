import { Tree } from './tree.js';

class App {
  constructor() {
    this.canvas = document.createElement('canvas');
    document.body.appendChild(this.canvas);

    this.ctx = this.canvas.getContext('2d');
    this.pixelRatio = window.devicePixelRatio > 1 ? 2 : 1;

    // add click
    window.addEventListener('resize', this.resize.bind(this), false);
    window.addEventListener('click', this.click.bind(this), false);
    this.resize();
  }

  resize() {
    this.stageWidth = window.innerWidth;
    this.stageHeight = window.innerHeight;

    this.canvas.width = this.stageWidth * this.pixelRatio;
    this.canvas.height = this.stageHeight * this.pixelRatio;
    this.ctx.scale(this.pixelRatio, this.pixelRatio);

     // Set styles for the body and canvas
    document.body.style.margin = '0';
    document.body.style.overflow = 'hidden';
    this.canvas.style.display = 'block';

    this.ctx.clearRect(0, 0, this.stageWidth, this.stageHeight);
  }

  // click fuction
  click(event) {
    const { clientX } = event;
    Tree.isFirstBranch = true;  // Reset First Branch to true on every click
    new Tree(this.ctx, clientX, this.stageHeight);
  }
}

window.onload = () => {
  new App();
};
